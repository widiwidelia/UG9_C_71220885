print("========== DAFTAR BELANJA ==========")
print("========== Daftar 1 ==========")
print("Daftar Belanja 1: ['Sikat Gigi', 'Odol', 'Shampo', 'Sabun', 'Ciduk']")

Daftar1 = []

print("========== Daftar 2 ==========")
print("Daftar Belanja 2: ['Teh', 'Gula', 'Garam', 'Micin', 'Kecap']")

print("Jawab dengan angka [1/2]")
print("1. Rubah Belanjaan")
print("2. Keluar")

if "1"

pilihan = int(input("Masukkan Pilihan : "))
item1 = str(input("Masukkan nama item ke daftar 1 : "))
index = int(input("Masukkan index yang ingin dirubah :"))
item2 = str(input("Masukkan nama item ke daftar 2 : "))
index = int(input("Masukkan index yang ingin dirubah: "))
