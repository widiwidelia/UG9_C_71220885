

nama = str(input("Masukkan nama Anda : "))
mata = str(input("Masukkan mata kuliah : "))
grup = str(input("Masukkan grup : "))
print("Haloo!",nama)
print(nama,"tergabung dalam kelas",mata,"pada grup",grup)
