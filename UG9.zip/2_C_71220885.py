cepat = int(input("Masukkan kecepatan waktu tempuh : "))
waktu = int(input("Masukkan waktu yang diperlukan : "))

#rumus
bensin = cepat*waktu/10
biaya = bensin*15000

print("Teman Anda mengisi bensin sebanyak ",bensin," Liter")
print("Biaya yang dikeluarkan untuk mengisi bensin adalah Rp. ",biaya)
